/**
Shalev Yohanan
May 15, 2021
*/
package Json;

@SuppressWarnings("serial")
public class JsonQueryException extends Exception {

	public JsonQueryException(String string) {
		super(string);
	}

}
