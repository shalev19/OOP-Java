/**
Shalev Yohanan
May 15, 2021
*/
package Json;

@SuppressWarnings("serial")
public class JsonSyntaxException extends Exception {
	public JsonSyntaxException(String string) {
        super(string);
    }
}
